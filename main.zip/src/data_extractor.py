import glob
import config
import pandas as pd


def get_test_path_single_assignment_question(question_id):

    test_path = glob.glob(config.test_path.format(question_id))
    return test_path[0]


def get_data_path_single_question(question_id):
    wrong_data_paths = glob.glob(config.wrong_path.format(question_id))
    reference_data_path = glob.glob(config.ref_path.format(question_id))
    return wrong_data_paths, reference_data_path

def read_code(path):
    code = ''
    with open(path, 'r') as f:
        for line in f.readlines():
            if 'print' not in line:
                code += line
            elif '#print' in line:
                pass
            else:
                code += line.split('print')[0]+'pass\n'
        f.close()
    return code

def get_rps_by_path(csv_path, prog):
    df = pd.read_csv(csv_path)
    prog_data = df.loc[df['File Name'] == prog]
    rps = str(prog_data['RPS'].values[0])
    print(prog, rps)
    if rps != 'nan':
        return float(rps)
    return rps

def add_rps_data(question_id, names, total_mark=100):
    df = pd.read_csv('refactory_question_{}.csv'.format(question_id))
    csv_path = config.refactory_data_path.format(question_id)
    rps_list = []
    for name in names:
        rps = get_rps_by_path(csv_path, name)
        if rps == 'nan':
            rps_list.append(-100.0)
        else:
            rps_list.append(total_mark * (max(0, 1-rps)))
    df.insert(5, 'rps_grading', rps_list, True)
    df.to_csv('refactory_question_{}.csv'.format(question_id), index=False)


def get_fixed_solution(question_id, name):
    name = name.split('/')[-1]
    csv_path = config.refactory_data_path.format(question_id)

    df_fix = pd.read_csv(csv_path)
    df_fix = df_fix[['File Name', 'Status', 'Repair', '#Passed Test Case', '#Test Case']]
    df_target = df_fix[(df_fix['File Name'] == name) & (df_fix['Status'].isin(['success_w_mut', 'success_wo_mut']))]
    if len(df_target) == 0:
        return None
    fixed_code = df_target['Repair'].values[0]
    fname = '/tmp/fixed_' + name
    f = open(fname, 'w')
    f.write(fixed_code)
    f.close()
    return fname


def data_split(question_id, size=45):
    import random, os, shutil
    dir_name = 'question_{}_size_{}'.format(question_id, size)
    if not os.path.exists(dir_name):
        os.mkdir(dir_name)
    progs = sorted(glob.glob(config.wrong_path.format(question_id)))
    random.seed(12)
    random.shuffle(progs)
    chunked_progs = [progs[i:i+size] for i in range(0, len(progs), size)]
    for i, chunk in enumerate(chunked_progs):
        subdir_name = dir_name + '/group_{}'.format(i)
        os.mkdir(subdir_name)
        for file in chunk:
            shutil.copy(file, subdir_name + '/')

# get_rps_by_path(config.refactory_data_path.format(4), 'wrong_4_042.py')

