from src.evaluation import concept_based

import time

def main():
    total_mark = 100
    tasks = {
             # Task
    }
    concept_based.run_concept_based(tasks)
    
if __name__ == '__main__':
    start = time.time()
    main()
    stop = time.time()
    print((stop-start)/60)
