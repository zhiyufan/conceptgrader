import os

ROOT = os.path.dirname(os.path.abspath(__file__))

RESULTS_PATH = ROOT + '/results/'

DATA_PATH = ROOT + '/data/'

GROUND_TRUTH_PATH = ROOT + '/data/task{}_tutors.json'

TEST_BASED_PATH = RESULTS_PATH + '/test_based_result_question_{}.json'
CONCEPT_BASED_PATH = RESULTS_PATH + '/concept_based_result_question_{}.json'
CFG_BASED_PATH = RESULTS_PATH + '/cfg_based_result_question_{}.json'


wrong_path = DATA_PATH + 'question_{}/code/wrong/*.py'

ref_path = DATA_PATH + 'question_{}/code/reference/*.py'

test_path = DATA_PATH + 'question_{}/ans/'

# refactory_data_path = DATA_PATH + 'question_{}/refactory_online.csv'

refactory_data_path = '/home/zhiyu/refactory/data/question_{}/refactory_online.csv'
